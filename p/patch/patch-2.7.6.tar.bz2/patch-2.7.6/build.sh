#!/bin/bash
set -e

# Patch 2.7.6 build script based on LFS 12.4

# Configure
./configure --prefix=/usr

# Build
make

# Install
make DESTDIR=$DESTDIR install
